#!/usr/bin/env node

/**
 * Righetto Premortem Guardian — single command dispatcher.
 *
 * It is intentionally dependency-light. Real site adapters can be connected
 * later without changing the cognitive sequence.
 */

import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const base = path.join(root, "righetto-premortem-guardian");
const configPath = path.join(base, "config", "guardian.yaml");
const memoryDir = path.join(base, "memory");
const reportsDir = path.join(base, "reports");

function ensure() {
  fs.mkdirSync(memoryDir, { recursive: true });
  fs.mkdirSync(reportsDir, { recursive: true });
}

function now() {
  return new Date().toISOString();
}

function event(type, data = {}) {
  ensure();
  fs.appendFileSync(
    path.join(memoryDir, "events.jsonl"),
    JSON.stringify({ time: now(), type, ...data }) + "\n"
  );
}

function printSequence() {
  console.log(`
RIGHETTO PREMORTEM GUARDIAN

CONTEXT
  ↓
OBSERVE
  ↓
VERIFY
  ↓
ASSUMPTIONS
  ↓
PREMORTEM
  ↓
FAILURE MODES
  ↓
PRIORITIZE
  ↓
ACT
  ↓
VERIFY AGAIN
  ↓
LEARN
  ↓
NEXT CHECK
`);
}

function run() {
  ensure();

  const result = {
    status: "ok",
    timestamp: now(),
    sequence: [
      "context",
      "observe",
      "verify",
      "assumptions",
      "premortem",
      "failure_modes",
      "prioritize",
      "act",
      "verify_again",
      "learn",
      "next_check"
    ],
    mode: "dispatcher-ready",
    note:
      "Core sequence loaded. Connect site-specific adapters for live checks and remediation."
  };

  fs.writeFileSync(
    path.join(reportsDir, "guardian-latest.json"),
    JSON.stringify(result, null, 2)
  );

  fs.writeFileSync(
    path.join(reportsDir, "guardian-latest.md"),
    `# Guardian Report\n\n- Status: ${result.status}\n- Time: ${result.timestamp}\n- Mode: ${result.mode}\n\nSequence executed: ${result.sequence.join(" → ")}\n\n${result.note}\n`
  );

  event("guardian_run", result);
  printSequence();
  console.log("Guardian run completed.");
  console.log(`Report: ${path.relative(root, path.join(reportsDir, "guardian-latest.md"))}`);
}

function doctor() {
  ensure();
  const required = [
    "README.md",
    "ONE_COMMAND.md",
    "AGENT.md",
    "config/guardian.yaml",
    "config/cron-matrix.yaml",
    "policy/autonomy.yaml",
    "sequences/master-sequence.md",
    "skill/SKILL.md"
  ];

  const missing = required.filter((f) => !fs.existsSync(path.join(base, f)));

  console.log("Righetto Guardian Doctor");
  console.log(missing.length ? "FAIL" : "OK");

  if (missing.length) {
    console.log("Missing:");
    missing.forEach((x) => console.log(`- ${x}`));
    process.exitCode = 1;
  }
}

const command = process.argv[2] || "run";

if (command === "run") run();
else if (command === "doctor") doctor();
else if (command === "sequence") printSequence();
else {
  console.log("Usage: guardian.mjs [run|doctor|sequence]");
  process.exitCode = 1;
}
